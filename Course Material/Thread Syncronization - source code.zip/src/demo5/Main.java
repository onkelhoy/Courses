package demo5;

public class Main {

	public static void main(String[] args) {
//		System.out.println("Synchronized methods");
//		new SynchronizedMethods().main();
		
//		System.out.println("\n\nMultiple locks, using synchronized code blocks");
		new SynchronizedCodeBlocks().main();
	}

}

